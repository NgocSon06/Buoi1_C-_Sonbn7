﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoInheritance
{
    public sealed class Camel
    {
        private const int AGE = 10;
        public void Run()
        {
            Console.WriteLine("Camel run");
        }
    }
}
