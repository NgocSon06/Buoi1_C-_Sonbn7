﻿using System;

namespace MTA_Day2
{
    class Program
    {
        static void Main(string[] args)
        {
            //ArrayMax.TinhThuong();
            //ArrayMenu.ExArray2();
            //int[] array = { 1, 5, 7, 4, 3, 10, 8 };
            //QuickSort.Sort(array, 0, array.Length - 1);
            //Console.WriteLine(string.Join(", ", array));

            //BinaryFile.WriteFile();
            //BinaryFile.ReadFile();

            DienTichHinhHoc.TinhDienTich();
        }
    }
}
